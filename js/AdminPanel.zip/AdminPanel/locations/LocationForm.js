// js/AdminPanel/locations/LocationForm.js
export default class LocationForm {
  constructor(loc = null) {
    this.loc = loc;
  }

  render() {
    return `
      <input id="locName" class="w-full border px-3 py-2 rounded" placeholder="Name"
             value="${this.loc?.name || ''}">

      <select id="locType" class="w-full border px-3 py-2 rounded">
        <option value="">Select Type</option>
        <option value="Education Center" ${this.loc?.type === "Education Center" ? "selected" : ""}>Education Center</option>
        <option value="Private location" ${this.loc?.type === "Private location" ? "selected" : ""}>Private location</option>
        <option value="Public location" ${this.loc?.type === "Public location" ? "selected" : ""}>Public location</option>
      </select>

      <input id="locCity" class="w-full border px-3 py-2 rounded" placeholder="City"
             value="${this.loc?.city || ''}">
      <input id="locRegion" class="w-full border px-3 py-2 rounded" placeholder="Region"
             value="${this.loc?.region || ''}">
      <input id="locAddress" class="w-full border px-3 py-2 rounded" placeholder="Address"
             value="${this.loc?.address || ''}">
      <input id="locContact" class="w-full border px-3 py-2 rounded" placeholder="Contact"
             value="${this.loc?.contact || ''}">
      <input id="locHours" class="w-full border px-3 py-2 rounded" placeholder="Hours"
             value="${this.loc?.hours || ''}">

      <label class="block font-semibold mt-4">Archived</label>
      <select id="locArchived" class="w-full border px-3 py-2 rounded">
        <option value="false" ${!this.loc?.isArchived ? 'selected' : ''}>No</option>
        <option value="true" ${this.loc?.isArchived ? 'selected' : ''}>Yes</option>
      </select>
    `;
  }

  getData() {
    return {
      name: document.getElementById('locName').value.trim(),
      type: document.getElementById('locType').value,
      city: document.getElementById('locCity').value.trim(),
      region: document.getElementById('locRegion').value.trim(),
      address: document.getElementById('locAddress').value.trim(),
      contact: document.getElementById('locContact').value.trim(),
      hours: document.getElementById('locHours').value.trim(),
      isArchived: document.getElementById('locArchived').value === 'true'
    };
  }
}
