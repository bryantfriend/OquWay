// js/AdminPanel/locations/LocationEditor.js
import LocationService from "./LocationService.js";
import PhotoUploader from "../ui/PhotoUploader.js";
import SocialLinksEditor from "./SocialLinksEditor.js";
import { withButtonSpinner } from "../ui/withButtonSpinner.js";
import { LOCATION_TYPES } from "../ui/constants.js";

export default class LocationEditor {
  constructor(panelTitle, panelContent, loc = null) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.loc = loc;
    this.photoUploader = null;
    this.socialEditor = null;
  }

  async render() {
    this.panelTitle.textContent = this.loc ? `Edit: ${this.loc.name}` : "Add New Location";

    this.panelContent.innerHTML = `
      <div class="bg-white p-6 rounded shadow max-w-xl space-y-3">
                <label class="block font-semibold">Status</label>
        <select id="locArchived" class="w-full border px-3 py-2 rounded">
          <option value="false" ${!this.loc?.isArchived ? "selected" : ""}>Active</option>
          <option value="true" ${this.loc?.isArchived ? "selected" : ""}>Inactive</option>
        </select>

        <div id="photoUploaderContainer" class="mb-3"></div>

        <label class="block font-semibold">Social Links</label>
        <div id="socialLinksContainer" class="space-y-2"></div>
                        <div class="flex gap-4 mt-6">
                    <button type="button" id="saveBtn" class="bg-green-600 text-white px-4 py-2 rounded flex items-center gap-2">
            💾 Save
          </button>
          <button type="button" id="cancelBtn" class="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
                  </div>
      </div>
    `;

    // Photo uploader
    //this.photoUploader = new PhotoUploader("photoUploaderContainer", this.loc?.photoUrl || "", "locations");
    //this.photoUploader.render();

    // Social links editor
    this.socialEditor = new SocialLinksEditor("socialLinksContainer", this.loc?.socialLinks || {});
    // --- CHANGE START: Await the async render method to prevent race conditions ---
    await this.socialEditor.render();
    // --- CHANGE END ---

    // Save & Cancel
    withButtonSpinner("saveBtn", () => this.save());
    document.getElementById("cancelBtn").addEventListener("click", async () => {
      const { default: LocationsDashboard } = await import("./LocationsDashboard.js");
      new LocationsDashboard(this.panelTitle, this.panelContent).render();
    });
  }

async save() {
    // --- CHANGE START: Get all form elements at the beginning ---
    const nameInput = document.getElementById("locName");
    const typeInput = document.getElementById("locType");
    const cityInput = document.getElementById("locCity");
    const regionInput = document.getElementById("locRegion");
    const addressInput = document.getElementById("locAddress");
    const contactInput = document.getElementById("locContact");
    const hoursInput = document.getElementById("locHours");
    const archivedInput = document.getElementById("locArchived");
    // --- CHANGE END ---

    // Inline validation
    let isValid = true;

    if (!nameInput.value.trim()) {
      document.getElementById("errorName").classList.remove("hidden");
      nameInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorName").classList.add("hidden");
      nameInput.classList.remove("border-red-500");
    }

    if (!typeInput.value) {
      document.getElementById("errorType").classList.remove("hidden");
      typeInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorType").classList.add("hidden");
      typeInput.classList.remove("border-red-500");
    }

    if (!cityInput.value.trim()) {
      document.getElementById("errorCity").classList.remove("hidden");
      cityInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorCity").classList.add("hidden");
      cityInput.classList.remove("border-red-500");
    }

    if (!isValid) return;

    // --- CHANGE START: Use the variables defined above to collect data ---
    const data = {
      name: nameInput.value.trim(),
      type: typeInput.value,
      city: cityInput.value.trim(),
      region: regionInput.value.trim(),
      address: addressInput.value.trim(),
      contact: contactInput.value.trim(),
      hours: hoursInput.value.trim(),
      isArchived: archivedInput.value === "true",
      socialLinks: this.socialEditor.getLinks(),
    };
    // --- CHANGE END ---

    // Upload photo if changed
    const photoUrl = await this.photoUploader.saveImage(this.loc?.id || "new");
    data.photoUrl = photoUrl;

    if (this.loc?.id) {
      await LocationService.update(this.loc.id, data);
    } else {
      await LocationService.create(data);
    }

    const { default: LocationsDashboard } = await import("./LocationsDashboard.js");
    new LocationsDashboard(this.panelTitle, this.panelContent).render();
  }
}
