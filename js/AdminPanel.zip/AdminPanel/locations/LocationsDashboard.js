// js/AdminPanel/locations/LocationsDashboard.js
import { showGlobalLoader, hideGlobalLoader } from "../../utilities.js";
import LocationService from "./LocationService.js";
import LocationList from "./LocationList.js";

export default class LocationsDashboard {
  constructor(panelTitle, panelContent) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.locations = [];
    this.locationList = null;
  }

  async render() {
    showGlobalLoader("Loading Locations...");
    this.locations = await LocationService.getAll();
    hideGlobalLoader();

    // --- CHANGE START: Get unique types for the filter dropdown ---
    const locationTypes = [...new Set(this.locations.map(l => l.type).filter(Boolean))];
    // --- CHANGE END ---

    this.panelTitle.textContent = "Locations";
    this.panelContent.innerHTML = `
      <div class="mb-4 flex flex-wrap gap-4 justify-between items-center">
        <div class="flex-grow">
          <input id="locSearch" class="border px-3 py-2 rounded w-full md:w-auto" placeholder="Search locations...">
        </div>
        <div class="flex flex-wrap gap-4">
          <select id="locTypeFilter" class="border px-3 py-2 rounded">
            <option value="all">All Types</option>
            ${locationTypes.map(type => `<option value="${type}">${type}</option>`).join('')}
          </select>
                    <select id="locStatusFilter" class="border px-3 py-2 rounded">
            <option value="active" selected>Active</option>
            <option value="inactive">Inactive</option>
            <option value="all">All</option>
          </select>

          <select id="locSort" class="border px-3 py-2 rounded">
            <option value="name-asc">Name (A-Z)</option>
            <option value="name-desc">Name (Z-A)</option>
            <option value="newest">Newest</option>
            <option value="oldest">Oldest</option>
          </select>
                    <button id="addLocationBtn" class="bg-blue-600 text-white px-4 py-2 rounded">+ Add Location</button>
        </div>
      </div>
      <div id="locList" class="grid gap-4 grid-cols-1 md:grid-cols-2 lg:grid-cols-3"></div>
    `;

    this.locationList = new LocationList(this.panelTitle, this.panelContent, this.locations);
    this.applyFilters();
    this.bindEvents();
  }

  bindEvents() {
    // --- CHANGE START: Add event listeners for new dropdowns ---
    this.panelContent.querySelector("#locSearch")?.addEventListener("input", () => this.applyFilters());
    this.panelContent.querySelector("#locStatusFilter")?.addEventListener("change", () => this.applyFilters());
    this.panelContent.querySelector("#locTypeFilter")?.addEventListener("change", () => this.applyFilters());
    this.panelContent.querySelector("#locSort")?.addEventListener("change", () => this.applyFilters());
    // --- CHANGE END ---

    this.panelContent.querySelector("#addLocationBtn")?.addEventListener("click", async () => {
      const { default: LocationEditor } = await import("./LocationEditor.js");
      new LocationEditor(this.panelTitle, this.panelContent).render();
    });
  }

  applyFilters() {
    const search = this.panelContent.querySelector("#locSearch").value.toLowerCase();
    // --- CHANGE START: Get values from new dropdowns ---
    const statusFilter = this.panelContent.querySelector("#locStatusFilter").value;
    const typeFilter = this.panelContent.querySelector("#locTypeFilter").value;
    const sort = this.panelContent.querySelector("#locSort").value;
    // --- CHANGE END ---

    let filtered = this.locations.filter(l =>
      l.name?.toLowerCase().includes(search) ||
      l.city?.toLowerCase().includes(search) ||
      l.type?.toLowerCase().includes(search)
    );

    // Apply Type filter
    if (typeFilter !== "all") {
        filtered = filtered.filter(l => l.type === typeFilter);
    }

    // Apply Active/Inactive filter
    if (statusFilter === "active") {
      filtered = filtered.filter(l => !l.isArchived);
    } else if (statusFilter === "inactive") {
      filtered = filtered.filter(l => l.isArchived);
    }

    // --- CHANGE START: Apply Sorting ---
    switch (sort) {
        case 'name-asc':
            filtered.sort((a, b) => a.name.localeCompare(b.name));
            break;
        case 'name-desc':
            filtered.sort((a, b) => b.name.localeCompare(a.name));
            break;
        case 'newest':
            filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
            break;
        case 'oldest':
            filtered.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt));
            break;
    }
    // --- CHANGE END ---

    this.locationList.render(filtered);
  }
}