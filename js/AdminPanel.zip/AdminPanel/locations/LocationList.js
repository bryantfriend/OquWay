// js/AdminPanel/locations/LocationList.js
export default class LocationList {
  constructor(panelTitle, panelContent, locations) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.locations = locations;
  }

  render(filteredLocations = null) {
    const listEl = this.panelContent.querySelector("#locList");
    if (!listEl) return;

    const locsToRender = filteredLocations || this.locations;

    if (locsToRender.length === 0) {
      listEl.innerHTML = `<p class="text-gray-500">No locations found.</p>`;
      return;
    }

    listEl.innerHTML = locsToRender.map(l => this.renderLocationCard(l)).join("");

    listEl.querySelectorAll("[data-loc-id]").forEach(card => {
      card.addEventListener("click", () => this.openLocationDetail(card.dataset.locId));
    });
  }

  renderLocationCard(loc) {
    const photo = loc.photoDataUrl || "https://upload.wikimedia.org/wikipedia/commons/6/65/No-Image-Placeholder.svg";
    const status = loc.isArchived
      ? `<span class="text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">Inactive</span>`
      : `<span class="text-xs bg-green-100 text-green-600 px-2 py-0.5 rounded-full">Active</span>`;

    return `
      <div class="bg-white p-4 rounded shadow-sm border hover:shadow-md hover:bg-blue-50 cursor-pointer"
           data-loc-id="${loc.id}">
        <div class="flex items-center gap-4">
          <img src="${photo}" alt="Location Photo" class="w-16 h-16 rounded border object-cover" />
          <div>
            <h3 class="text-lg font-semibold">${loc.name}</h3>
            <p class="text-sm text-gray-500">${loc.city || "—"} • ${loc.type || "—"}</p>
            <div class="mt-1">${status}</div>
          </div>
        </div>
      </div>
    `;
  }

  async openLocationDetail(locId) {
    const { default: LocationDetail } = await import("./LocationDetail.js");
    const loc = this.locations.find(l => l.id === locId);
    new LocationDetail(this.panelTitle, this.panelContent, loc).render();
  }
}
