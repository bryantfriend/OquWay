// js/AdminPanel/locations/LocationCard.js
import LocationView from './LocationView.js';

export default class LocationCard {
  constructor(loc, onClick) {
    this.loc = loc;
    this.onClick = onClick;
  }

  render() {
    const view = new LocationView(this.loc, "compact");
    return `
      <div class="bg-white rounded shadow p-4 hover:bg-blue-50 cursor-pointer transition"
           data-loc-id="${this.loc.id}">
        ${view.render()}
      </div>
    `;
  }

  attachEvents(container) {
    const cardEl = container.querySelector(`[data-loc-id="${this.loc.id}"]`);
    if (cardEl) {
      cardEl.addEventListener('click', () => this.onClick(this.loc));
    }
  }
}
