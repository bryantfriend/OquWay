import ClassService from "./ClassService.js";
import PhotoUploader from "../ui/PhotoUploader.js";
import { withButtonSpinner } from "../ui/withButtonSpinner.js";

export default class ClassEditor {
  constructor(panelTitle, panelContent, cls = null) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.cls = cls; // if null → new class
    this.photoUploader = null;
  }

  async render() {
    this.panelTitle.textContent = this.cls ? `Edit: ${this.cls.name}` : "Add New Class";

    this.panelContent.innerHTML = `
      <div class="bg-white p-6 rounded shadow max-w-xl space-y-3">

        <label class="block font-semibold">Class Name <span class="text-red-500">*</span></label>
        <input id="clsName" class="w-full border px-3 py-2 rounded mb-1"
               value="${this.cls?.name || ""}">
        <p id="errorName" class="text-red-500 text-sm hidden">Name is required</p>

        <label class="block font-semibold">Subject <span class="text-red-500">*</span></label>
        <input id="clsSubject" class="w-full border px-3 py-2 rounded mb-1"
               value="${this.cls?.subject || ""}">
        <p id="errorSubject" class="text-red-500 text-sm hidden">Subject is required</p>

        <label class="block font-semibold">Language <span class="text-red-500">*</span></label>
        <input id="clsLanguage" class="w-full border px-3 py-2 rounded mb-1"
               value="${this.cls?.language || ""}">
        <p id="errorLanguage" class="text-red-500 text-sm hidden">Language is required</p>

        <label class="block font-semibold">Grade Level <span class="text-red-500">*</span></label>
        <input id="clsGrade" class="w-full border px-3 py-2 rounded mb-1"
               value="${this.cls?.gradeLevel || ""}">
        <p id="errorGrade" class="text-red-500 text-sm hidden">Grade level is required</p>

        <div id="photoUploaderContainer" class="mb-3"></div>

        <div class="flex gap-4 mt-6">
          <button id="saveBtn" class="bg-green-600 text-white px-4 py-2 rounded flex items-center gap-2">
            💾 Save
          </button>
          <button id="cancelBtn" class="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
        </div>
      </div>
    `;

    this.photoUploader = new PhotoUploader("photoUploaderContainer", this.cls?.photoUrl || "", "classes");
    this.photoUploader.render();

    withButtonSpinner("saveBtn", () => this.save());
    document.getElementById("cancelBtn").addEventListener("click", async () => {
      const { default: ClassesDashboard } = await import("./ClassesDashboard.js");
      new ClassesDashboard(this.panelTitle, this.panelContent).render();
    });
  }

  async save() {
    const nameInput = document.getElementById("clsName");
    const subjectInput = document.getElementById("clsSubject");
    const langInput = document.getElementById("clsLanguage");
    const gradeInput = document.getElementById("clsGrade");

    let isValid = true;

    if (!nameInput.value.trim()) {
      document.getElementById("errorName").classList.remove("hidden");
      nameInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorName").classList.add("hidden");
      nameInput.classList.remove("border-red-500");
    }

    if (!subjectInput.value.trim()) {
      document.getElementById("errorSubject").classList.remove("hidden");
      subjectInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorSubject").classList.add("hidden");
      subjectInput.classList.remove("border-red-500");
    }

    if (!langInput.value.trim()) {
      document.getElementById("errorLanguage").classList.remove("hidden");
      langInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorLanguage").classList.add("hidden");
      langInput.classList.remove("border-red-500");
    }

    if (!gradeInput.value.trim()) {
      document.getElementById("errorGrade").classList.remove("hidden");
      gradeInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorGrade").classList.add("hidden");
      gradeInput.classList.remove("border-red-500");
    }

    if (!isValid) return;

    const data = {
      name: nameInput.value.trim(),
      subject: subjectInput.value.trim(),
      language: langInput.value.trim(),
      gradeLevel: gradeInput.value.trim(),
    };

    const photoUrl = await this.photoUploader.saveImage(this.cls?.id || "new");
    data.photoUrl = photoUrl;

    if (this.cls?.id) {
      await ClassService.update(this.cls.id, data);
    } else {
      await ClassService.create(data);
    }

    const { default: ClassesDashboard } = await import("./ClassesDashboard.js");
    new ClassesDashboard(this.panelTitle, this.panelContent).render();
  }
}
