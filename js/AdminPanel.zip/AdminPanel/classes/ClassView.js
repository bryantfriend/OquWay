import ClassService from "./ClassService.js";
import { withButtonSpinner, spinnerButton } from "../ui/withButtonSpinner.js";

export default class ClassView {
  constructor(panelTitle, panelContent, cls) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.cls = cls;
  }

  render() {
    this.panelTitle.textContent = this.cls.name;

    const scheduleHtml = this.cls.schedule
      ? Object.entries(this.cls.schedule).map(([day, times]) =>
          `<li><strong>${day}:</strong> ${times.start} - ${times.end}</li>`
        ).join("")
      : "<li class='text-gray-500'>No schedule set</li>";

    this.panelContent.innerHTML = `
      ${spinnerButton("backBtn", "← Back", "blue")}
      <div class="bg-white p-6 rounded shadow space-y-2 max-w-xl">
        ${this.cls.photoDataUrl 
          ? `<img src="${this.cls.photoDataUrl}" alt="Class Photo" class="w-24 h-24 rounded border mb-4" />`
          : ""}
        <p><strong>Name:</strong> ${this.cls.name}</p>
        <p><strong>Login Display:</strong> ${this.cls.loginDisplayName || "—"}</p>
        <p><strong>Subject:</strong> ${this.cls.subject || "—"}</p>
        <p><strong>Grade Level:</strong> ${this.cls.gradeLevel || "—"}</p>
        <p><strong>Language:</strong> ${this.cls.language || "—"}</p>
        <p><strong>Teacher:</strong> ${this.cls.teacherName || "—"}</p>
        
        <div>
          <strong>Schedule:</strong>
          <ul class="list-disc list-inside">${scheduleHtml}</ul>
        </div>

        <div>
          <strong>Students:</strong>
          <ul class="list-disc list-inside">
            ${this.cls.students && this.cls.students.length
              ? this.cls.students.map(s => `<li>${s}</li>`).join("")
              : "<li class='text-gray-500'>No students assigned</li>"}
          </ul>
        </div>

        <div class="flex gap-2 mt-4">
          <button id="editBtn" class="bg-yellow-500 text-white px-4 py-2 rounded">✏️ Edit</button>
          ${spinnerButton("deleteBtn", "🗑️ Delete", "red")}
        </div>
      </div>
    `;

    // Back with spinner
    document.getElementById("backBtn").addEventListener("click", () => {
      withButtonSpinner("backBtn", async () => {
        const { default: ClassesDashboard } = await import("./ClassesDashboard.js");
        new ClassesDashboard(this.panelTitle, this.panelContent).render();
      }, "← Back");
    });

    // Edit
    document.getElementById("editBtn").addEventListener("click", async () => {
      const { default: ClassEditor } = await import("./ClassEditor.js");
      new ClassEditor(this.panelTitle, this.panelContent, this.cls).render();
    });

    // Delete with spinner
    document.getElementById("deleteBtn").addEventListener("click", () => {
      if (!confirm("Are you sure you want to delete this class?")) return;

      withButtonSpinner("deleteBtn", async () => {
        await ClassService.remove(this.cls.id);
        const { default: ClassesDashboard } = await import("./ClassesDashboard.js");
        new ClassesDashboard(this.panelTitle, this.panelContent).render();
      }, "🗑️ Delete");
    });
  }
}
