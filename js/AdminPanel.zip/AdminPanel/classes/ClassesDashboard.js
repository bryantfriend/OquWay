import ClassService from "./ClassService.js";
import { showGlobalLoader, hideGlobalLoader } from "../../utilities.js";
import { GRADE_LEVELS, LANGUAGES } from "../ui/constants.js";

export default class ClassesDashboard {
  constructor(panelTitle, panelContent, locations = []) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.locations = locations;
    this.classes = [];
    this.selectedLocationId = null;
  }

  async render() {
    showGlobalLoader("Loading Classes...");
    this.classes = await ClassService.getAll();
    hideGlobalLoader();

    const locationOptions = this.locations
      .map(loc => `<option value="${loc.id}">${loc.name}</option>`)
      .join("");

    this.panelTitle.textContent = "Classes";
    this.panelContent.innerHTML = `
      <div class="mb-4 flex flex-wrap gap-4 justify-between items-center">
        <div class="flex gap-2 items-center">
          <label for="locationSelect" class="font-medium">Location:</label>
          <select id="locationSelect" class="border px-3 py-2 rounded">
            <option value="">All Locations</option>
            ${locationOptions}
          </select>
        </div>
        <div class="flex gap-2">
          <button id="addClassBtn" class="bg-blue-600 text-white px-4 py-2 rounded">+ Add Class</button>
        </div>
      </div>
      <div id="classList" class="grid grid-cols-1 md:grid-cols-2 gap-6"></div>
    `;

    this.bindEvents();
    this.renderClassList();
  }

  bindEvents() {
    this.panelContent.querySelector("#locationSelect")?.addEventListener("change", (e) => {
      this.selectedLocationId = e.target.value;
      this.renderClassList();
    });

    this.panelContent.querySelector("#addClassBtn")?.addEventListener("click", async () => {
      const { default: ClassEditor } = await import("./ClassEditor.js");
      new ClassEditor(this.panelTitle, this.panelContent).render();
    });
  }

  renderClassList() {
    const listEl = this.panelContent.querySelector("#classList");
    if (!listEl) return;

    const filtered = this.selectedLocationId
      ? this.classes.filter(c => c.location_id === this.selectedLocationId)
      : this.classes;

    if (filtered.length === 0) {
      listEl.innerHTML = `<p class="text-gray-500">No classes found.</p>`;
      return;
    }

    listEl.innerHTML = filtered.map(cls => this.renderClassCard(cls)).join("");

    listEl.querySelectorAll("[data-class-id]").forEach(card => {
      card.addEventListener("click", () => this.openClassView(card.dataset.classId));
    });
  }

  renderClassCard(cls) {
    return `
      <div class="bg-white p-4 rounded shadow-sm border hover:shadow-md hover:bg-blue-50 cursor-pointer"
           data-class-id="${cls.id}">
        <div class="flex items-center gap-4">
          <img src="${cls.photoUrl}" class="w-16 h-16 object-cover rounded border" alt="Class Photo" />
          <div>
            <h3 class="text-lg font-semibold">${cls.name || "Unnamed Class"}</h3>
            ${cls.loginDisplayName ? `<p class="text-xs text-gray-400 italic">${cls.loginDisplayName}</p>` : ""}
            <p class="text-sm text-gray-500">
              ${cls.subject || "<span class='italic text-gray-400'>No subject</span>"} 
              • ${cls.language || LANGUAGES[0]} • ${cls.gradeLevel || GRADE_LEVELS[0]}
            </p>
            ${cls.isArchived
              ? `<span class="inline-block mt-1 text-xs bg-red-100 text-red-600 px-2 py-0.5 rounded-full">Archived</span>`
              : ""}
          </div>
        </div>
      </div>
    `;
  }

  async openClassView(classId) {
    const cls = this.classes.find(c => c.id === classId);
    if (!cls) return;

    const { default: ClassView } = await import("./ClassView.js");
    new ClassView(this.panelTitle, this.panelContent, cls).render();
  }
}
