import { showGlobalLoader, hideGlobalLoader } from "../../utilities.js";
import { USER_ROLES } from "../ui/constants.js";
import UserService from "./UserService.js";
import UserList from "./UserList.js";

export default class UsersDashboard {
  constructor(panelTitle, panelContent, locations = [], classes = []) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.locations = locations;
    this.classes = classes;
    this.users = [];
    this.userList = null;
  }

  async render() {
    showGlobalLoader("Loading Users...");
    this.users = await UserService.getAll();
    hideGlobalLoader();

    this.panelTitle.textContent = "Users";
    this.panelContent.innerHTML = `
      <div class="mb-4 flex justify-between">
        <input id="userSearch" class="border px-3 py-2 rounded" placeholder="Search users...">
        <button id="addUserBtn" class="bg-blue-600 text-white px-4 py-2 rounded">+ Add User</button>
      </div>
      <div class="mb-4">
        <label class="font-medium">Role:</label>
        <select id="roleFilter" class="border px-3 py-2 rounded ml-2">
          <option value="">All</option>
          ${USER_ROLES.map(r => `<option value="${r}">${r}</option>`).join("")}
        </select>
      </div>
      <div id="userList" class="grid gap-4"></div>
    `;

    // 🔹 switch between "view" or "detail"
    this.userList = new UserList(this.panelTitle, this.panelContent, this.users, this.locations, this.classes, "view");
    this.userList.render();

    this.bindEvents();
  }

  bindEvents() {
    this.panelContent.querySelector("#userSearch")?.addEventListener("input", () => this.applyFilters());
    this.panelContent.querySelector("#roleFilter")?.addEventListener("change", () => this.applyFilters());

    this.panelContent.querySelector("#addUserBtn")?.addEventListener("click", async () => {
      const { default: UserEditor } = await import("./UserEditor.js");
      new UserEditor(this.panelTitle, this.panelContent, null, this.locations, this.classes).render();
    });
  }

  applyFilters() {
    const search = this.panelContent.querySelector("#userSearch").value.toLowerCase();
    const role = this.panelContent.querySelector("#roleFilter").value;

    const filtered = this.users.filter(u =>
      u.name?.toLowerCase().includes(search) &&
      (role === "" || u.role === role)
    );

    this.userList.render(filtered);
  }
}
