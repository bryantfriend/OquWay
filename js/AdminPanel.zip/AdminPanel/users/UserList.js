export default class UserList {
  constructor(panelTitle, panelContent, users, locations = [], classes = [], mode = "view") {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.users = users;
    this.locations = locations;
    this.classes = classes;
    this.mode = mode; // "view" (default) or "detail"
  }

  render(filteredUsers = null) {
    const listEl = this.panelContent.querySelector("#userList");
    if (!listEl) return;

    const usersToRender = filteredUsers || this.users;

    if (usersToRender.length === 0) {
      listEl.innerHTML = `<p class="text-gray-500">No users found.</p>`;
      return;
    }

    listEl.innerHTML = usersToRender.map(u => this.renderUserCard(u)).join("");

    listEl.querySelectorAll("[data-user-id]").forEach(card => {
      card.addEventListener("click", () => this.openUser(this.mode, card.dataset.userId));
    });
  }

  renderUserCard(u) {
    return `
      <div class="bg-white p-4 rounded shadow-sm border hover:shadow-md hover:bg-blue-50 cursor-pointer"
           data-user-id="${u.id}">
        <div class="flex items-center gap-4">
          <img src="${u.photoUrl}" class="w-12 h-12 rounded-full border" alt="User Photo" />
          <div>
            <h3 class="text-lg font-semibold">${u.name}</h3>
            <p class="text-sm text-gray-500 capitalize">${u.role}</p>
          </div>
        </div>
      </div>
    `;
  }

  async openUser(mode, userId) {
    const user = this.users.find(u => u.id === userId);
    if (!user) return;

    if (mode === "detail") {
      const { default: UserDetail } = await import("./UserDetail.js");
      new UserDetail(this.panelTitle, this.panelContent, user.id, this.locations, this.classes).render();
    } else {
      const { default: UserView } = await import("./UserView.js");
      new UserView(this.panelTitle, this.panelContent, user, this.locations, this.classes).render();
    }
  }
}
