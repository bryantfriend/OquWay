import { db } from "../../firebase-init.js";
import {
  collection, getDocs, getDoc, addDoc, updateDoc, deleteDoc, doc
} from "https://www.gstatic.com/firebasejs/11.10.0/firebase-firestore.js";

import { DEFAULT_PHOTO } from "../ui/constants.js";

export default class UserService {
  static normalize(data, id) {
    return {
      id,
      name: data.name || "",
      email: data.email || "",
      role: data.role || "student",
      photoUrl: data.photoUrl || DEFAULT_PHOTO,
      locationId: data.locationId || "",
      classId: data.classId || "",
      fruitPassword: data.fruitPassword || null,
      createdAt: data.createdAt || null,
      updatedAt: data.updatedAt || null,
    };
  }

  static async getAll() {
    const snap = await getDocs(collection(db, "users"));
    return snap.docs.map(d => this.normalize(d.data(), d.id));
  }

  static async getOne(id) {
    const snap = await getDoc(doc(db, "users", id));
    return snap.exists() ? this.normalize(snap.data(), snap.id) : null;
  }

  static async create(data) {
    return await addDoc(collection(db, "users"), {
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  static async update(id, data) {
    return await updateDoc(doc(db, "users", id), {
      ...data,
      updatedAt: new Date().toISOString(),
    });
  }

  static async remove(id) {
    return await deleteDoc(doc(db, "users", id));
  }
}
