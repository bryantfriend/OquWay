import UserService from "./UserService.js";
import PhotoUploader from "../ui/PhotoUploader.js";
import { withButtonSpinner } from "../ui/withButtonSpinner.js";
import { FRUIT_EMOJIS } from "../../config.js";

export default class UserEditor {
  constructor(panelTitle, panelContent, user = null, locations = [], classes = []) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.user = user;
    this.locations = locations;
    this.classes = classes;
    this.photoUploader = null;
    this.selectedFruits = [];
  }

  async render() {
    this.panelTitle.textContent = this.user ? `Edit: ${this.user.name}` : "Add New User";

    this.panelContent.innerHTML = `
      <div class="bg-white p-6 rounded shadow max-w-xl space-y-3">

        <label class="block font-semibold">Name <span class="text-red-500">*</span></label>
        <input id="userName" class="w-full border px-3 py-2 rounded mb-1" value="${this.user?.name || ""}">
        <p id="errorName" class="text-red-500 text-sm hidden">Name is required</p>

        <label class="block font-semibold">Role <span class="text-red-500">*</span></label>
        <select id="userRole" class="w-full border px-3 py-2 rounded mb-1">
          <option value="">Select Role</option>
          <option value="student" ${this.user?.role === "student" ? "selected" : ""}>Student</option>
          <option value="teacher" ${this.user?.role === "teacher" ? "selected" : ""}>Teacher</option>
          <option value="admin" ${this.user?.role === "admin" ? "selected" : ""}>Admin</option>
        </select>
        <p id="errorRole" class="text-red-500 text-sm hidden">Role is required</p>

        <label class="block font-semibold">Location <span class="text-red-500">*</span></label>
        <select id="userLocation" class="w-full border px-3 py-2 rounded mb-1">
          <option value="">Assign Location</option>
          ${this.locations.map(l => `<option value="${l.id}" ${this.user?.locationId === l.id ? "selected" : ""}>${l.name}</option>`).join("")}
        </select>
        <p id="errorLocation" class="text-red-500 text-sm hidden">Location is required</p>

        <label class="block font-semibold">Class</label>
        <select id="userClass" class="w-full border px-3 py-2 rounded mb-1">
          <option value="">Assign Class</option>
          ${this.classes.map(c => `<option value="${c.id}" ${this.user?.classId === c.id ? "selected" : ""}>${c.name}</option>`).join("")}
        </select>
        <p id="errorClass" class="text-red-500 text-sm hidden">Class is required for students</p>

        <button id="openFruitModal" class="w-full border px-3 py-2 rounded text-left">
          ${this.user?.fruitPassword?.length ? this.user.fruitPassword.join("") : "🍎🍌 — Click to Set Fruit Password"}
        </button>
        <input type="hidden" id="fruitPassword" value='${JSON.stringify(this.user?.fruitPassword || [])}' />
        <p id="errorFruit" class="text-red-500 text-sm hidden">Fruit password is required for students</p>

        <div id="photoUploaderContainer" class="mb-3"></div>

        <div class="flex gap-4 mt-6">
          <button id="saveBtn" class="bg-green-600 text-white px-4 py-2 rounded flex items-center gap-2">
            💾 Save
          </button>
          <button id="cancelBtn" class="bg-gray-400 text-white px-4 py-2 rounded">Cancel</button>
        </div>
      </div>

      <!-- Fruit Modal -->
      <div id="fruitModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 hidden">
        <div class="bg-white rounded p-6 w-full max-w-xs text-center">
          <h2 class="text-lg font-semibold mb-4">Select 4 Fruit Emojis</h2>
          <div id="fruitSelection" class="grid grid-cols-3 gap-2 mb-4">
            ${FRUIT_EMOJIS.map(fruit => `<button class="fruit-btn border p-2 rounded text-xl">${fruit}</button>`).join("")}
          </div>
          <div id="selectedFruits" class="flex justify-center space-x-2 text-2xl mb-4"></div>
          <button id="clearFruits" class="text-red-500 text-sm mb-2">Clear</button>
          <div class="space-x-4">
            <button id="cancelFruitModal" class="px-4 py-2 rounded bg-gray-300">Cancel</button>
            <button id="saveFruitPassword" class="px-4 py-2 rounded bg-green-600 text-white">Save</button>
          </div>
        </div>
      </div>
    `;

    // Photo uploader
    this.photoUploader = new PhotoUploader("photoUploaderContainer", this.user?.photoUrl || "", "users");
    this.photoUploader.render();

    // Fruit modal logic
    this.initFruitModal();

    // Save & Cancel
    withButtonSpinner("saveBtn", () => this.save());
    document.getElementById("cancelBtn").addEventListener("click", async () => {
      const { default: UsersDashboard } = await import("./UsersDashboard.js");
      new UsersDashboard(this.panelTitle, this.panelContent).render();
    });
  }

  initFruitModal() {
    const modal = document.getElementById("fruitModal");
    const openBtn = document.getElementById("openFruitModal");
    const clearBtn = document.getElementById("clearFruits");
    const cancelBtn = document.getElementById("cancelFruitModal");
    const saveBtn = document.getElementById("saveFruitPassword");
    const selectedFruitsEl = document.getElementById("selectedFruits");
    const hiddenInput = document.getElementById("fruitPassword");

    // Load existing
    this.selectedFruits = this.user?.fruitPassword || [];

    const updateFruitPreview = () => {
      selectedFruitsEl.innerHTML = this.selectedFruits.map(f => `<span>${f}</span>`).join("");
    };
    updateFruitPreview();

    openBtn.addEventListener("click", () => {
      this.selectedFruits = [];
      updateFruitPreview();
      modal.classList.remove("hidden");
    });

    document.querySelectorAll(".fruit-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        if (this.selectedFruits.length < 4) {
          this.selectedFruits.push(btn.textContent);
          updateFruitPreview();
        }
      });
    });

    clearBtn.addEventListener("click", () => {
      this.selectedFruits = [];
      updateFruitPreview();
    });

    cancelBtn.addEventListener("click", () => {
      modal.classList.add("hidden");
    });

    saveBtn.addEventListener("click", () => {
      if (this.selectedFruits.length !== 4) {
        alert("Please select exactly 4 fruits.");
        return;
      }
      hiddenInput.value = JSON.stringify(this.selectedFruits);
      openBtn.innerText = this.selectedFruits.join("");
      modal.classList.add("hidden");
    });
  }

  async save() {
    const nameInput = document.getElementById("userName");
    const roleInput = document.getElementById("userRole");
    const locInput = document.getElementById("userLocation");
    const classInput = document.getElementById("userClass");
    const fruitInput = document.getElementById("fruitPassword");

    let isValid = true;

    if (!nameInput.value.trim()) {
      document.getElementById("errorName").classList.remove("hidden");
      nameInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorName").classList.add("hidden");
      nameInput.classList.remove("border-red-500");
    }

    if (!roleInput.value) {
      document.getElementById("errorRole").classList.remove("hidden");
      roleInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorRole").classList.add("hidden");
      roleInput.classList.remove("border-red-500");
    }

    if (!locInput.value) {
      document.getElementById("errorLocation").classList.remove("hidden");
      locInput.classList.add("border-red-500");
      isValid = false;
    } else {
      document.getElementById("errorLocation").classList.add("hidden");
      locInput.classList.remove("border-red-500");
    }

    if (roleInput.value === "student") {
      if (!classInput.value) {
        document.getElementById("errorClass").classList.remove("hidden");
        classInput.classList.add("border-red-500");
        isValid = false;
      } else {
        document.getElementById("errorClass").classList.add("hidden");
        classInput.classList.remove("border-red-500");
      }

      const fruitPassword = JSON.parse(fruitInput.value || "[]");
      if (fruitPassword.length !== 4) {
        document.getElementById("errorFruit").classList.remove("hidden");
        isValid = false;
      } else {
        document.getElementById("errorFruit").classList.add("hidden");
      }
    }

    if (!isValid) return;

    const data = {
      name: nameInput.value.trim(),
      role: roleInput.value,
      locationId: locInput.value,
      classId: classInput.value || null,
      fruitPassword: JSON.parse(fruitInput.value || "[]"),
    };

    const photoUrl = await this.photoUploader.saveImage(this.user?.id || "new");
    data.photoUrl = photoUrl;

    if (this.user?.id) {
      await UserService.update(this.user.id, data);
    } else {
      await UserService.create(data);
    }

    const { default: UsersDashboard } = await import("./UsersDashboard.js");
    new UsersDashboard(this.panelTitle, this.panelContent).render();
  }
}
