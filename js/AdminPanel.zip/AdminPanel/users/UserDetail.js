import UserService from "./UserService.js";

export default class UserDetail {
  constructor(panelTitle, panelContent, userId, locations = [], classes = []) {
    this.panelTitle = panelTitle;
    this.panelContent = panelContent;
    this.userId = userId;
    this.locations = locations;
    this.classes = classes;
    this.user = null;
  }

  async render() {
    this.user = await UserService.getOne(this.userId);
    if (!this.user) {
      this.panelContent.innerHTML = `<p class="text-red-500">User not found.</p>`;
      return;
    }

    this.panelTitle.textContent = `${this.user.name} — Details`;

    const locationName =
      this.locations.find(l => l.id === this.user.locationId)?.name || "—";
    const className =
      this.classes.find(c => c.id === this.user.classId)?.name || "—";

    this.panelContent.innerHTML = `
      <button id="backBtn" class="text-blue-500 mb-4 hover:underline">← Back</button>
      <div class="bg-white p-6 rounded shadow max-w-2xl space-y-4">
        <div class="flex items-center gap-4">
          <img src="${this.user.photoUrl}" 
               alt="User Photo" 
               class="w-24 h-24 rounded-full border object-cover" />
          <div>
            <h2 class="text-2xl font-bold">${this.user.name}</h2>
            <p class="text-gray-600">${this.user.email || "—"}</p>
            <p class="text-gray-500 text-sm">Role: ${this.user.role}</p>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <p><strong>Location:</strong> ${locationName}</p>
          <p><strong>Class:</strong> ${className}</p>
          <p><strong>Fruit Password:</strong> ${
            this.user.fruitPassword
              ? this.user.fruitPassword.join(" ")
              : "<span class='text-gray-400 italic'>Not set</span>"
          }</p>
          <p><strong>Created At:</strong> ${this.user.createdAt || "—"}</p>
          <p><strong>Updated At:</strong> ${this.user.updatedAt || "—"}</p>
        </div>

        <div id="auditLog" class="mt-6">
          <h3 class="text-lg font-semibold mb-2">Audit Log</h3>
          <ul class="list-disc list-inside text-sm text-gray-600">
            <li>Feature coming soon: show activity log for user actions.</li>
          </ul>
        </div>

        <div class="flex gap-3 mt-6">
          <button id="editBtn" class="bg-yellow-500 text-white px-4 py-2 rounded">✏️ Edit</button>
          <button id="deleteBtn" class="bg-red-600 text-white px-4 py-2 rounded">🗑️ Delete</button>
        </div>
      </div>
    `;

    document.getElementById("backBtn").addEventListener("click", async () => {
      const { default: UsersDashboard } = await import("./UsersDashboard.js");
      new UsersDashboard(this.panelTitle, this.panelContent, this.locations, this.classes).render();
    });

    document.getElementById("editBtn").addEventListener("click", async () => {
      const { default: UserEditor } = await import("./UserEditor.js");
      new UserEditor(this.panelTitle, this.panelContent, this.user, this.locations, this.classes).render();
    });

    document.getElementById("deleteBtn").addEventListener("click", async () => {
      if (!confirm("Are you sure you want to delete this user?")) return;
      await UserService.remove(this.user.id);
      const { default: UsersDashboard } = await import("./UsersDashboard.js");
      new UsersDashboard(this.panelTitle, this.panelContent, this.locations, this.classes).render();
    });
  }
}
